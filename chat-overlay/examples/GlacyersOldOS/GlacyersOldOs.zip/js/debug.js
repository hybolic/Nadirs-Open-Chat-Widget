const lorem_ipsum = ["Lorem ipsum dolor sit amet, consectetur adipiscing elit" , "Duis ac tristique lectus, eget bibendum ex" , "Nam commodo lorem purus, in aliquet ligula finibus sit amet" , "Mauris elementum dui libero, sit amet fermentum justo aliquet et" , "Aenean sit amet est justo" , "Suspendisse faucibus est hendrerit tellus ullamcorper, scelerisque molestie mi volutpat" , "Integer lectus sapien, malesuada eget faucibus eget, lobortis eu ligula" , "Nullam egestas at purus nec feugiat" , "Nulla in condimentum orci." , "Etiam viverra, sapien interdum gravida lacinia, dui lorem lobortis odio, vel malesuada augue erat id lorem"
,"Nullam malesuada nulla quis euismod hendrerit" , "Nulla non diam consequat, auctor neque vitae, ornare sapien" , "Pellentesque ac massa sed ex cursus malesuada et nec lorem" , "Vestibulum id metus est" , "Duis mauris dolor, placerat quis tincidunt egestas, rutrum ac magna" , "Pellentesque in enim iaculis orci vestibulum pellentesque." , "Quisque malesuada egestas diam, vel scelerisque tellus scelerisque eu" , "Aenean pulvinar tellus porta est vulputate commodo" , "Suspendisse a ultrices dolor" , "Aenean nec nunc nisl"
,"Nunc facilisis tortor ac purus rhoncus, a euismod orci sagittis" , "Donec lacinia, nunc at rhoncus sodales, mi turpis scelerisque mauris, aliquet vulputate lacus orci at metus" , "Ut finibus porttitor porttitor" , "Proin et quam ornare, lacinia eros nec, egestas lacus" , "Nam non fringilla lacus." , "Suspendisse eros ipsum, laoreet sed faucibus ut, rhoncus vel odio" , "Pellentesque blandit est eu ipsum vehicula blandit" , "Proin non blandit sapien" , "Praesent quis vehicula lacus, nec feugiat sem" , "Curabitur luctus, lectus in condimentum consequat, dolor lorem rutrum magna, non interdum metus ante eget ante"
,"Sed eu neque sit amet nulla tempus tristique" , "Ut congue dictum magna" , "Proin hendrerit pellentesque semper" , "Sed et diam nec est condimentum ullamcorper pellentesque sed nisi" , "Fusce vulputate libero at urna scelerisque venenatis" , "Nulla convallis diam vel arcu auctor venenatis" , "Morbi ultricies ligula nec ipsum varius finibus eget in lacus" , "In sodales nibh in velit volutpat, sit amet laoreet lectus iaculis" , "Suspendisse volutpat felis sed vehicula auctor" , "Nullam sagittis vulputate quam, commodo vestibulum lorem ultricies nec"
,"Maecenas massa erat, posuere in semper laoreet, pellentesque id elit." , "Nunc convallis eget nibh ac consectetur" , "Curabitur vestibulum ligula lorem, sollicitudin venenatis orci pellentesque et" , "Quisque ullamcorper posuere odio a finibus" , "Praesent porta dapibus massa, vel mollis ante" , "Sed porta ultrices laoreet" , "Duis tortor nunc, dictum in lorem quis, ornare lacinia mi" , "Nulla tempor neque at scelerisque iaculis" , "Nulla facilisi" , "Nunc dignissim placerat elit vitae interdum."
,"Pellentesque convallis euismod diam, tempor consectetur mauris viverra vel" , "Duis at augue vitae felis consequat sodales" , "Nam eleifend bibendum vehicula" , "Donec eu tortor a neque tincidunt ullamcorper" , "Nulla eget libero non metus porttitor congue" , "Vivamus nec turpis varius, dignissim nisi ut, rhoncus eros" , "Aenean eu interdum nunc" , "Proin suscipit mauris orci, in interdum ex rhoncus nec" , "Suspendisse ut lorem vestibulum, feugiat metus quis, iaculis diam." , "Proin quis mauris in dui laoreet rhoncus"
,"Ut at felis efficitur, posuere velit a, varius quam" , "Morbi fermentum pellentesque vehicula" , "Praesent tincidunt nulla in eros rhoncus varius" , "Sed tempor consequat dolor, at efficitur elit ultrices ac" , "Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus" , "Nulla nec ullamcorper ipsum, et feugiat ex" , "Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas" , "Nunc vulputate non nunc vel luctus" , "Nulla a libero non orci dapibus aliquet" , "Integer laoreet faucibus neque, et congue dolor lobortis ut."
,"Maecenas ultricies venenatis tellus, sit amet dignissim velit sollicitudin pretium" , "Interdum et malesuada fames ac ante ipsum primis in faucibus" , "Sed vitae urna sed neque volutpat tincidunt quis at lacus" , "Ut auctor malesuada dui blandit fringilla" , "Etiam porttitor elit neque, at tempus risus tempus in" , "Aliquam dapibus consectetur lacus vel cursus" , "Donec a augue quis diam finibus fermentum quis blandit augue" , "Ut quis lectus quis massa euismod viverra" , "Aliquam ipsum velit, aliquam quis urna eget, efficitur elementum dui" , "Suspendisse nec lacus posuere turpis ultricies elementum"
,"Suspendisse potenti" , "Nulla quis risus lectus" , "Nullam cursus eros ut urna semper suscipit" , "Suspendisse varius efficitur mauris a porta" , "In vel posuere nibh." , "Donec maximus non lacus a dignissim" , "Sed sit amet pretium magna, dapibus lobortis lacus" , "Nunc nec tempus dolor" , "Curabitur orci metus, hendrerit vehicula scelerisque at, sodales eu augue" , "Curabitur tempor tincidunt ligula nec ultrices"
,"Etiam sagittis tristique ipsum, id auctor purus tempor quis" , "Mauris bibendum quis diam sed vehicula" , "Sed at felis libero" , "Integer auctor est eu condimentum porta" , "Phasellus pulvinar magna id nibh volutpat, non semper odio ultrices" , "Vivamus tempus purus vitae nulla venenatis mollis." , "Duis molestie velit non risus sollicitudin ullamcorper" , "Donec imperdiet nibh eget augue sollicitudin aliquam" , "Vestibulum odio est, ultrices vel varius id, rhoncus eu quam" , "Donec placerat diam sed ante congue varius"
,"In a dolor nisl" , "Curabitur aliquet rutrum dolor vehicula sagittis" , "Ut hendrerit, massa quis iaculis dictum, orci purus consequat erat, et euismod massa ligula id elit" , "Integer id pharetra purus" , "Nunc vitae facilisis erat" , "Mauris nec sem tellus" , "Nunc arcu odio, elementum eu faucibus ut, porta sit amet felis" , "Etiam dapibus, lorem ac tincidunt tincidunt, nibh erat commodo metus, vel egestas quam felis vitae lectus" , "Fusce auctor nisl eu orci pellentesque, id finibus justo sodales." , "Pellentesque luctus tincidunt erat ac blandit"
,"Quisque vitae finibus risus" , "Nam ac iaculis nisl, varius sollicitudin nisi" , "Nulla nec mollis mauris, sit amet consequat ante" , "Duis varius, nulla sit amet finibus tempor, ligula massa finibus nibh, id porttitor ligula dui et dolor" , "Aliquam ac arcu urna" , "Mauris non ante eu diam pharetra laoreet" , "Morbi ultrices tellus mi" , "Donec eros nulla, tempus accumsan orci vel, sagittis iaculis enim." , "Morbi aliquam, sem non aliquam dictum, nibh augue volutpat turpis, a egestas justo massa vitae nulla" , "Fusce et risus eget dui euismod mollis" ]


function sleep(min,max) { sleep_amount = Math.max(getRandomInt(max), min); return new Promise(r => setTimeout(r, sleep_amount)); }
function getRandomBool() { return (getRandomInt(2) % 2) == 0; }
function getRandomInt(max) { return Math.floor(Math.random() * max); }
var counter = 1
function genFakeFlags() {
    counter++
    return { broadcaster : false
        , mod : ((getRandomInt(100) % 4) == 0)
        , founder : false
        , artist : ((getRandomInt(100) % 4) == 0)
        , subscriber : ((getRandomInt(100) % 4) == 0)
        , vip : ((getRandomInt(100) % 4) == 0)
        , highlighted : ((counter % 5) == 0)
        , customReward : false}
}

function genFakeExtra(user, flags) {
    var color = "#000000".replace(/0/g,function(){return (~~(Math.random()*16)).toString(16);});
    var sub_months = flags.subscriber ? ([1,3,6,9,12,24,48,60,72])[getRandomInt(8)] : 0;
    return {
    id : "AAAAAAAA-AAAA-AAAA-AAAA-AAAAAAAAAAAA",
    channel : settings.username,
    roomId : "10000000",
    messageType : "chat",
    messageEmotes : {},
    isEmoteOnly : false,
    userId : "10000000",
    username : user,
    displayName : user,
    userColor : color,
    userBadges : {
        subscriber : sub_months.toString()
    },
    userState : {
        badge_info : {
            subscriber : "86"
        },
        badges : {
            subscriber : sub_months.toString()
        },
        client_nonce : "AAAAAAAAAAAAAAAAAAAAAAAAAAAA",
        color : color,
        display_name : user,
        emotes : {},
        first_msg : false,
        flags : null,
        id : "AAAAAAAA-AAAA-AAAA-AAAA-AAAAAAAAAAAA",
        mod : flags.mod,
        returning_chatter : false,
        room_id : "10000000",
        subscriber : flags.subscriber,
        tmi_sent_ts : "0",
        turbo : false,
        user_id : getRandomInt(9999999999).toString(),
        user_type : null,
        emotes_raw : "",
        badge_info_raw : "subscriber/86",
        badges_raw : "subscriber/"+sub_months.toString(),
        username : user,
        message_type : "chat"
    },
    customRewardId : null, flags : null, timestamp : "1000000000000" }
}